<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "food".
 *
 * @property int $id
 * @property string $food_name
 * @property string $type
 * @property int $section_id
 * @property int $price
 *
 * @property Section $section
 * @property OrderHistory[] $orderHistories
 */
class Food extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'food';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['food_name', 'type', 'section_id', 'price'], 'required'],
            [['section_id', 'price'], 'integer'],
            [['food_name'], 'string', 'max' => 20],
            [['type'], 'string', 'max' => 10],
            [['section_id'], 'exist', 'skipOnError' => true, 'targetClass' => Section::className(), 'targetAttribute' => ['section_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'food_name' => 'Food Name',
            'type' => 'Type',
            'section_id' => 'Section ID',
            'price' => 'Price',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSection()
    {
        return $this->hasOne(Section::className(), ['id' => 'section_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOrderHistories()
    {
        return $this->hasMany(OrderHistory::className(), ['food_id' => 'id']);
    }
}
