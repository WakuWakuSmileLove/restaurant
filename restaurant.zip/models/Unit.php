<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "unit".
 *
 * @property int $id
 * @property string $unit_name
 * @property int $unit1
 * @property int $unit2
 * @property string $unit1_name
 * @property string $unit2_name
 *
 * @property Outcome[] $outcomes
 */
class Unit extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'unit';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['unit_name', 'unit1', 'unit2', 'unit1_name', 'unit2_name'], 'required'],
            [['unit1', 'unit2'], 'integer'],
            [['unit_name'], 'string', 'max' => 50],
            [['unit1_name', 'unit2_name'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'unit_name' => 'Unit Name',
            'unit1' => 'Unit1',
            'unit2' => 'Unit2',
            'unit1_name' => 'Unit1 Name',
            'unit2_name' => 'Unit2 Name',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOutcomes()
    {
        return $this->hasMany(Outcome::className(), ['outcome_unit' => 'id']);
    }
}
