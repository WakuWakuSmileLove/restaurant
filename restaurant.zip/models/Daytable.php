<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "daytable".
 *
 * @property int $id
 * @property int $order_id
 * @property string $food_name
 * @property int $price
 * @property int $quantity
 * @property string $date
 * @property int $food_id
 */
class Daytable extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'daytable';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['order_id', 'food_name', 'price', 'quantity', 'date', 'food_type','food_id'], 'required'],
            [['order_id', 'price', 'quantity', 'food_id'], 'integer'],
            [['food_name', 'date'], 'string', 'max' => 10],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'order_id' => 'Order ID',
            'food_name' => 'Food Name',
            'price' => 'Price',
            'quantity' => 'Quantity',
            'date' => 'Date',
            'food_type' => 'Food Type',
            'food_id' =>'Food ID',
        ];
    }
}
