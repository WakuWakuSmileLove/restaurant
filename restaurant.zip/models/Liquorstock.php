<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "liquorstock".
 *
 * @property int $id
 * @property int $food_id
 * @property string $food_name
 * @property int $total_qty
 */
class Liquorstock extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'liquorstock';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['food_id', 'food_name', 'total_qty'], 'required'],
            [['food_id', 'total_qty'], 'integer'],
            [['food_name'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'food_id' => 'Food ID',
            'food_name' => 'Food Name',
            'total_qty' => 'Total Qty',
        ];
    }
}
