<?php

namespace app\models;

use Yii;
use yii\base\Model;

/**
 * ContactForm is the model behind the contact form.
 */
class FoodForm extends Model
{
    public $food_name;
    public $type;
    public $section;
    public $price;


    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            // name, email, subject and body are required
            [['food_name', 'type', 'section', 'price'], 'required'],

        ];
    }



}
