<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "outcome".
 *
 * @property int $id
 * @property string $outcome_title
 * @property string $outcome_name
 * @property int $outcome_unit
 * @property double $outcome_quantity
 * @property double $unit_price
 * @property string $date
 * @property int $section_num
 *
 * @property Unit $outcomeUnit
 * @property Section $sectionNum
 */
class Outcome extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'outcome';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['outcome_unit', 'unit_price', 'section_num'], 'required'],
            [['outcome_unit', 'section_num'], 'integer'],
            [['outcome_quantity', 'unit_price'], 'number'],
            [['outcome_title', 'outcome_name'], 'string', 'max' => 100],
            [['date'], 'string', 'max' => 20],
            [['outcome_unit'], 'exist', 'skipOnError' => true, 'targetClass' => Unit::className(), 'targetAttribute' => ['outcome_unit' => 'id']],
            [['section_num'], 'exist', 'skipOnError' => true, 'targetClass' => Section::className(), 'targetAttribute' => ['section_num' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'outcome_title' => 'Outcome Title',
            'outcome_name' => 'Outcome Name',
            'outcome_unit' => 'Outcome Unit',
            'outcome_quantity' => 'Outcome Quantity',
            'unit_price' => 'Unit Price',
            'date' => 'Date',
            'section_num' => 'Section Num',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getOutcomeUnit()
    {
        return $this->hasOne(Unit::className(), ['id' => 'outcome_unit']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSectionNum()
    {
        return $this->hasOne(Section::className(), ['id' => 'section_num']);
    }
}
