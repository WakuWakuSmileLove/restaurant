<?php

/* @var $this \yii\web\View */
/* @var $content string */

use app\widgets\Alert;
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>

<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>



    <meta charset="<?= Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="refresh" content="10">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $this->registerCsrfMetaTags() ?>
            <link href="<?=Yii::$app->request->baseUrl;?>/css/receipt.css" rel="stylesheet" media="screen">
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>

    <style>
       .yii-debug-toolbar__bar{
         display: none!important;
       }
    </style>
</head>
<body>
<?php $this->beginBody() ?>

<div class="wrap">
    <?php
    NavBar::begin([
        'brandLabel' =>"Restaurant Order",
        'brandUrl' => Yii::$app->homeUrl,
        'options' => [
            'class' => 'navbar-inverse navbar-fixed-top',
            'style'=>'background-color:#563D7C;'
        ],
    ]);


    NavBar::end();
    ?>

<div class="container-fluid">

        <?= $content ?>
      </div>
        <!-- <div class="container">
    </div> -->
</div>

<!-- <footer class="footer">
    <div class="container">

        <p class="pull-right">Developed by Tri_</p>
    </div>
</footer> -->

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
