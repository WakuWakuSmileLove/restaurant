<?php

/* @var $this \yii\web\View */
/* @var $content string */

use app\widgets\Alert;
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>

<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>



    <meta charset="<?= Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $this->registerCsrfMetaTags() ?>
            <link href="<?=Yii::$app->request->baseUrl;?>/css/receipt.css" rel="stylesheet" media="screen">
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>

    <style>
       .yii-debug-toolbar__bar{
         display: none!important;
       }

       @page{
         size:80mm 105mm;
         margin:1mm;
       }




       @media print {
  .wrap{
    margin: 0!important;
    padding: 0!important;

  }

  .navbar-inverse
  *{
    margin: 0!important;
    display: none!important;
  }
  html,body{
    margin-left: 2mm;
    margin:0!important;
    padding: 0!important;
  }
  #table{

    display: none;
  }

  .tax{
    display: none!important;
  }

   .tt{
    width:80mm;
    margin: 0!important;
    padding:0!important;
  }
}

    </style>
</head>
<body>
<?php $this->beginBody() ?>

<div class="wrap">

    <?php
    NavBar::begin([
        'brandLabel' =>"Restaurant",
        'brandUrl' => Yii::$app->homeUrl,
        'options' => [
            'class' => 'navbar-inverse navbar-fixed-top',
            'id' =>'nav',
            'style'=>'background-color:#563D7C;'
        ],
    ]);
    echo Nav::widget([
        'options' => ['class' => 'navbar-nav navbar-right'],
        'items' => [
            ['label' => 'Home', 'url' => ['/restaurant/index']],
             

            ['label' => 'Sale Report', 'url' => ['/restaurant/account']],
            ['label' => 'Expense Summary', 'url' => ['/restaurant/outcomes']],
            ['label'=>'Accounting' ,'url'=>['/restaurant/totalprofit']],
             ['label' => 'Order', 'url' => ['/restaurant/ord']],
            [
              'label' => 'Create Item',
                'items' => [
                    ['label' => 'create food ', 'url' => ['/restaurant/food']],
                    '<li class="divider"></li>',

                    ['label' => 'create Expense ', 'url' => ['/restaurant/outcome']],

                    '<li class="divider"></li>',
                    ['label' => 'create section', 'url' => ['/restaurant/section']],
                    '<li class="divider"></li>',

                    ['label' => 'create type', 'url' => ['/restaurant/type']],
                    '<li class="divider"></li>',

                    ['label' => 'create seat', 'url' => ['/restaurant/seat']],
                    '<li class="divider"></li>',

                    ['label' => 'create unit', 'url' => ['/restaurant/unit']],
                    '<li class="divider"></li>',

                    ['label' => 'Add Liquorstock', 'url' => ['/restaurant/liquorstock']],

                    
                    

               ]],
             

        ],
    ]);

    NavBar::end();
    ?>

<div class="container-fluid">

  <div style="margin-top:55px;">
        <?= $content ?>
      </div>
      </div>
      </div>

    </div>

        <!-- <div class="container">
    </div> -->

<!-- <footer class="footer">
    <div class="container">

        <p class="pull-right">Developed by Tri_Tech</p>
    </div>
</footer> -->

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
