<?php
   use yii\bootstrap\ActiveForm;
   use yii\bootstrap\Html;
?>

<div class="restaurant-food">

<div class="body-content">

<div class ="row">
  <h1><?= Html::encode($this->title) ?></h1>

   <div class = "col-lg-5">
      <?php $form = ActiveForm::begin(); ?>
      <?= $form->field($model, 'food_name') ?>
      <?= $form->field($model, 'type')->listBox(
      $type);?>
      <?= $form->field($model, 'price') ?>

      <?= $form->field($model, 'section')->listBox(
      $section);?>

      <div class = "form-group">
         <?= Html::submitButton('Create', ['class' => 'btn btn-primary',
            'name' => 'food-button']) ?>
      </div>
      <?php ActiveForm::end(); ?>
   </div>
</div>
</div>
<div class="row">
  <div class="col-lg-6">

<h2>Discovery</h2>
<table class="table table-striped table-bordered">
<thead class="thead-dark">
  <tr>
    <th scope="col">ID</th>
    <th scope="col">Name</th>
    <th scope="col">Price</th>
    <th scope="col">Unit</th>
    <th scope="col">Edit</th>
    <th scope="col">Delete</th> 
  </tr>
</thead>

<tr> <?php   
                        foreach ($foodall as $d) {
                          // code...

                     ?>
      <tr class="service">
        <td class="tableitem"><p class="itemtext"><?= $d['id']?></p></td>
        <td class="tableitem"><p class="itemtext"><?= $d['food_name']?></p></td>
        <td class="tableitem"><p class="itemtext"><?= $d['price']?></p></td>
        <td class="tableitem"><p class="itemtext"></p></td>
        <td class="tableitem"><div><a class="btn" style="background-color:#563D7C;color:white;margin:0px;" id="tax" href="index.php?r=restaurant%2Fedit&id=<?=$d['id']?>">EDIT</a></div>
        </td>
        <td char="tableitem"><div><a class="btn" style="background: red;color: white;margin: 0px;" id="tax" href="index.php?r=restaurant%2Fdeletefood&id=<?=$d['id']?>">Delete</a></div></td>

      </tr>

<?php
}?>

   

</table>
</div>
</div>
</div>
