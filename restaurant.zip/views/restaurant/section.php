<?php
   use yii\bootstrap\ActiveForm;
   use yii\bootstrap\Html;
?>

<div class="restaurant-section">

<div class="body-content">

<div class ="row">
  <h1><?= Html::encode($this->title) ?></h1>

   <div class = "col-lg-5">
      <?php $form = ActiveForm::begin(); ?>
      <?= $form->field($model, 'section_name') ?>


      <div class = "form-group">
         <?= Html::submitButton('Create', ['class' => 'btn btn-primary',
            'name' => 'section-button']) ?>
      </div>
      <?php ActiveForm::end(); ?>
   </div>
</div>
</div>
</div>
