<?php 
use yii\bootstrap\ActiveForm;
use yii\bootstrap\Html;
?>
<div class="restaurant-outcome">
    <div class="body-content">
        <div class= "row">
            
            <h1><?=Html::encode($this->title)?></h1>

            <div class="col-lg-6">
                <?php $form=ActiveForm::begin(); ?>
                

                <?= $form->field($model,'outcome_title')?>

                <?= $form->field($model,'outcome_name')?>
                <?= $form->field($model,'outcome_unit')->listBox($unit);?>
                <?= $form->field($model,'outcome_quantity')?>
                 <?= $form->field($model, 'unit_price') ?>
                <?= $form->field($model,'section_num')->listBox($section)?>

                 <div class = "form-group">
         <?= Html::submitButton('Create', ['class' => 'btn btn-primary',
            'name' => 'food-button']) ?>


            
   



  </div>

            <?php ActiveForm::end(); ?>
      

            </div>
<!--            <div class="col-lg-6">


                <?php
                $total=0;

                 if($allout != null){

                    ?>

                 <table class="table table-bordered" style="margin-top:10px;">
      <tr>
        <th style="background-color:#777777;">Date</th>
        <th>Expense</th>
        <th>Total</th>
        <th>Action</th>
      </tr>

            <?php 
            foreach($allout as $d){


            

            ?>
        <tr>
            <td><?=$d['date']?></td>
            <td><?=$d['outcome_name']?></td>
            <td><?=$d['total']?></td>
            <td></td>
  

        </tr>

    <?php }?>


  



    </table>
 -->
<?php } ?>
            </div>



        </div>
    </div>
    </div>