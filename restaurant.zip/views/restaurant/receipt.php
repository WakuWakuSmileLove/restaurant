<?php
  use yii\bootstrap\ActiveForm;
  use yii\bootstrap\Html;
use \yii\bootstrap\Widget;
use yii\helpers\Url;

$this->registerMetaTag(['http-equiv' => 'refresh', 'content' => '8'], 'description');
?>
<?php $form = ActiveForm::begin([
        'method' => 'get',
        'action' => Url::to(['restaurant/swap']),
]);
?>
<input type="text" name="seat_num" value="<?=$data['seat_num']?>" hidden/>

    <input type="text" name="order_id" value="<?=$data['order_id']?>" hidden/>
    <input type="text" id="seat" name="seat" required placeholder="Enter seat" >
     <input type="submit" id="swap" class="btn btn-danger" value="Swap" hidden/>
    
     <?php ActiveForm::end(); ?>


<div class="row">

<div class="col-lg-5">

  

  <div id="table" >
    <table class="table table-striped table-bordered">
      <thead class="thead-dark">
      <tr>
        <th scope="col">Item</th>
        <th scope="col">Qty</th>
        <th scope="col">Sub Total</th>
        <th>Cancel</th>
      </tr>
    </thead>
  <?php    $data_receipt = $data_noord['data'];
                        foreach ($data_receipt as $d) {
                          // code...

                     ?>
      <tr class="service">
        <td class="tableitem"><p class="itemtext"><?= $d['food_name']?></p></td>
        <td class="tableitem"><p class="itemtext"><?= $d['qty']?></p></td>
        <td class="tableitem"><p class="itemtext"><?= $d['sub_total']?></p></td>
        <td class="tableitem"><a href="/restaurant/web/index.php?r=restaurant%2Fdeleteorder&order_history_id=<?= $d['order_history_id']?>&seat_num=<?=$data['seat_num']?>" class="btn btn-danger" style="width: 100%">Cancel</p></td>

      </tr>

<?php
}?>
      <!-- <tr class="service">
        <td class="tableitem"><p class="itemtext">Asset Gathering</p></td>
        <td class="tableitem"><p class="itemtext">3</p></td>
        <td class="tableitem"><p class="itemtext">$225.00</p></td>
      </tr>

      <tr class="service">
        <td class="tableitem"><p class="itemtext">Design Development</p></td>
        <td class="tableitem"><p class="itemtext">5</p></td>
        <td class="tableitem"><p class="itemtext">$375.00</p></td>
      </tr>

      <tr class="service">
        <td class="tableitem"><p class="itemtext">Animation</p></td>
        <td class="tableitem"><p class="itemtext">20</p></td>
        <td class="tableitem"><p class="itemtext">$1500.00</p></td>
      </tr>

      <tr class="service">
        <td class="tableitem"><p class="itemtext">Animation Revisions</p></td>
        <td class="tableitem"><p class="itemtext">10</p></td>
        <td class="tableitem"><p class="itemtext">$750.00</p></td>
      </tr> -->


      <tr class="tabletitle">
        <td> </td>
        <!-- <td class="Rate"><h2>tax</h2></td> -->
        <td></td>
        <td class="payment" colspan="2" ><a type="button" class="btn btn-primary" style="width:100%;" onclick="myFunction()">Print</a></td>

      </tr>


      <tr class="tabletitle">
        <td><a class="btn btn-danger" id="tax" href="/restaurant/web/index.php?r=restaurant%2Flist&id=<?= $data['id']?>&tax=0">No Tax(click)</a>
  <a class="btn btn-primary" id="notax" href="/restaurant/web/index.php?r=restaurant%2Flist&id=<?= $data['id']?>"> Tax(click)</a></td>
        <!-- <td class="Rate"><h2>tax</h2></td> -->
        <td></td>
         <td><a type="button" class="btn btn-primary" style="width:100%;" onclick="myFunction1()">Customer Print</a></td>
        <td class="payment" colspan="" ><a type="button" class="btn btn-primary" style="width:100%;" href="/restaurant/web/index.php?r=restaurant%2Fcashout&order_id=<?=$data['order_id']?>&total=<?=$data['total']?>&tax=<?=$data['tax']?>&seat_num=<?=$data['seat_num']?> ">CashOut</a></td>

      </tr>
       <script type="text/javascript">
            function myFunction1(){
          var x = document.getElementById("mydiv");
          /*if(x.style.display == "none"){
          x.style.display="block";
          }else{
          x.style.display="none";*/
        if(x.innerHTML === "Customer Receipt"){
          x.innerHTML = " Discovery Receipt";
        }else{
          x.innerHTML="Customer Receipt";
        }
    }

      
        </script>
      <!-- <tr class="tabletitle">
        <td></td>
        <td class="Rate"><h2>Total</h2></td>
        <td class="payment"><h2><?= $data['total']?></h2></td>
      </tr> -->

    </table>
  </div><!--End Table-->
</div>

       <!-- <center id="top"> -->

<div class="tt col-lg-7">


  <div>
 <div class="tt col-lg-7" style="width:80mm;align-content: center;">
    <?php if(!isset($_GET['tax']) || $data['tax']!=0):  ?>      
   <center><h3><b>Discovery Restaurant</b></h3>
    <h5>RadioBroadcasting Road,Airport Compound</h5>

   </center>

           <h5><b>Tel: 09400499400:0973237892</b></h5>
  <?php endif?>
            <h4><b>Seat Number <?= $data['seat_num'] ?>,      Order Id <?=$data['order_id']?></b></h4>
           

            
                <b>Date: 
              <?php 
                date_default_timezone_set("Asia/Yangon");  
        
               echo date("d/m/Y"); 
               ?>
               Time :
               <?php
               echo date("h:i:sa")
              ?>
             </b>
               <table class="table table-striped table-bordered">

                 <tr class="tabletitle">
                   <th class="item">Item</th>
                   <th class="Hours">Qty</th>
                   <th >Price</th>
                   <th class="Rate">Sub Total</th>
                 </tr>




                               <?php

                               $data_receipt = $data['data'];
                                   foreach ($data_receipt as $d) {
                                     // code...

                                ?>
                 <tr class="service">
                   <td class="tableitem"><b><p class="itemtext"><?= $d['food_name']?></p></b></td>
                   <td class="tableitem"><b><p class="itemtext"><?= $d['qty']?></p></b></td>

                   <td class="tableitem"><b><p class="itemtext"><?=$d['sub_total']/$d['qty']?></p></b></td>
                   <td class="tableitem"><b><p class="itemtext"><?= $d['sub_total']?></p></b></td>
                 </tr>

    <?php
    }?>
                 <!-- <tr class="service">
                   <td class="tableitem"><p class="itemtext">Asset Gathering</p></td>
                   <td class="tableitem"><p class="itemtext">3</p></td>
                   <td class="tableitem"><p class="itemtext">$225.00</p></td>
                 </tr>

                 <tr class="service">
                   <td class="tableitem"><p class="itemtext">Design Development</p></td>
                   <td class="tableitem"><p class="itemtext">5</p></td>
                   <td class="tableitem"><p class="itemtext">$375.00</p></td>
                 </tr>

                 <tr class="service">
                   <td class="tableitem"><p class="itemtext">Animation</p></td>
                   <td class="tableitem"><p class="itemtext">20</p></td>
                   <td class="tableitem"><p class="itemtext">$1500.00</p></td>
                 </tr>

                 <tr class="service">
                   <td class="tableitem"><p class="itemtext">Animation Revisions</p></td>
                   <td class="tableitem"><p class="itemtext">10</p></td>
                   <td class="tableitem"><p class="itemtext">$750.00</p></td>
                 </tr> -->


                 <tr class="tabletitle">
                   <td class="Rate" colspan="3"><h4><b>Total</b></h4></td>
                   <td class="payment" ><h4><b><?= $data['total']?></b></h4></td>
                 </tr>
                 <tr class="tabletitle">
                 	<td class="payment" colspan="3"><h4><b>Tax</b></h4></td>
                   <td class="payment"><h4><b><?= $data['tax']?></b></h4></td>
                 </tr>

               

                 <tr class="tabletitle">
                   <td class="Rate" colspan="3"><h3><b>Grand Total</b></h3></td>
                   <td class="payment"><h3><b><?= $data['total']+$data['tax']?></b></h3></td>
                 </tr>

               </table>
                <h4 align="center"> <div id="mydiv">Customer Receipt</div></h4>

             <!--End Table-->

             <!-- <div id="legalcopy">
               <p class="legal"><strong>Thank you for your business!</strong>  Payment is expected within 31 days; please process this invoice within that time. There will be a 5% interest charge per month on late invoices.
               </p>
             </div> -->

   </div>

   <script>



   function myFunction() {
     document.getElementById('tax').style.display = "none";

     document.getElementById('notax').style.display = "none";

document.getElementById('seat').style.display = "none";

     document.getElementById('swap').style.display = "none";
     window.onafterprint = function(){
       document.getElementById('tax').style.display = "inline";

       document.getElementById('notax').style.display = "inline"; 
       document.getElementById('seat').style.display = "inline";

       document.getElementById('swap').style.display = "inline";    }
       window.print();
   }
   </script>

 </div>
