<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Unit */
/* @var $form ActiveForm */
?>
<div class="restaurant-outcome">
    <div class="body-content">
        <div class= "row">
            
            <h1><?=Html::encode($this->title)?></h1>

            <div class="col-lg-6">
    <?php $form = ActiveForm::begin(); ?>

        <?= $form->field($model, 'unit_name') ?>
        <?= $form->field($model, 'unit1') ?>
        <?= $form->field($model, 'unit1_name') ?>
        <?= $form->field($model, 'unit2') ?>
        <?= $form->field($model, 'unit2_name') ?>
    
        <div class="form-group">
            <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
        </div>
    <?php ActiveForm::end(); ?>
</div>
</div>
</div>

</div><!-- unit -->
