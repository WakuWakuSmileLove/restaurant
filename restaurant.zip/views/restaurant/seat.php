<?php
   use yii\bootstrap\ActiveForm;
   use yii\bootstrap\Html;
?>

<div class="restaurant-section">

<div class="body-content">
  <?php if (Yii::$app->session->hasFlash('success')): ?>
    <div class="alert alert-success alert-dismissable">
    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
    <h4><i class="icon fa fa-check"></i>Saved!</h4>
    <?= Yii::$app->session->getFlash('success') ?>
    </div>
  <?php endif; ?>
<div class ="row">
  <h1><?= Html::encode($this->title) ?></h1>

   <div class = "col-lg-5">
      <?php $form = ActiveForm::begin(); ?>
      <?= $form->field($model, 'name') ?>


      <div class = "form-group">
         <?= Html::submitButton('Create', ['class' => 'btn btn-primary',
            'name' => 'section-button']) ?>
      </div>
      <?php ActiveForm::end(); ?>
   </div>
</div>
</div>
</div>
