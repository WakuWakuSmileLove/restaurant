<?php
   use yii\bootstrap\ActiveForm;
   use yii\bootstrap\Html;
?>

<div class="restaurant-section">

<div class="body-content">




<?php $form = ActiveForm::begin(
  [
              'action' => '/restaurant/web/index.php?r=restaurant%2Foutcomesz',
              'options' => [
                  'class' => 'form-inline'
               ]
          ]
  ); ?>

  <select class="form-control form-inline" name="section">

<div id='tshow'>
          <?php

            for ($i=0; $i<sizeof($section);$i++) {
              // code...



        if($sec == $section[$i]['id']){
?>
          <option id='section'value="<?=$section[$i]['id']?>" style="color:red;" selected><?=$section[$i]['name']?></option>
<?php
}else{?>
  <option value="<?=$section[$i]['id']?>" style="color:red;"><?=$section[$i]['name']?></option>

          <?php
        }
      }
        ?>
       </select>




       <select class="form-control form-inline" name="check1" id='checkbox'>
         <option value="0" style="color:red;" selected>Day</option>
         <option value="1" style="color:red;" >Month</option>
         <option value="2>" style="color:red;" >Year</option>
       </select>
       <input type="date" name="date1" id='dater'>
    <button class="btn btn-primary">Search</button>
</div>
    <h3>
  <h3>Expense Summary For <?=$date?> is printed out at
  <?php 
                date_default_timezone_set("Asia/Yangon");  
               

               echo date("Y/m/d"); 
               ?>
                
               <?php
               echo date("h:i:sa")



              ?>
</h3>
             

  <?php ActiveForm::end(); ?>


<div class="row">
  <div class="col-lg-4">
    <?php
    $total_kitchen=0;
if($kitchen != null){

   

    ?> 
    <h3>Kitchen room expense</h3>
    <table class="table table-bordered " style="margin-top:10px;">
      <tr>
      <th style="background-color: #777777; ">Expense Name</th>
      <th>Unit Price</th>
      <th>Unit</th>
      <th>Converted Unit</th>
      <th>Total Cost</th>
    </tr>
<?php 
      foreach ($kitchen as $key ) {
        # code...

        $total_kitchen=$total_kitchen+($key['qty']*$key['unit_price']);
        ?>
        <tr>
          <td><?=$key['outcome_name'];?></td>
          <td><?=$key['unit_price']?></td>
          <td><?=$key['qty']?><?=$key['unit1_name']?></td>
          <td><?=$key['qty']*$key['unit2']?><?=$key['unit2_name']?></td>
          <td><?=$key['qty']*$key['unit_price']?></td>

        </tr>




 <?php }?>

<tr>
  <td colspan="4">Total Kitchen Expense Cost</td>
<td><?=$total_kitchen?></td>

</tr>

    </table>
  
  <?php }?>

  </div>
  <div class="col-lg-4">
    <?php
    $total_bar=0;
  
if($bar != null){


    ?> 
    <h3>Bar expense</h3>
    <table class="table table-bordered " style="margin-top:10px;">
      <tr>
      <th style="background-color: #777777; ">Expense Name</th>
      <th>Unit Price</th>
      <th>Unit</th>
      <th>Converted Unit</th>
      <th>Total Cost</th>
    </tr>
<?php 
      foreach ($bar as $key ) {
        # code...

   $total_bar=$total_bar+($key['qty']*$key['unit_price']);


        ?>
          <tr>
          <td><?=$key['outcome_name'];?></td>
          <td><?=$key['unit_price']?></td>
          <td><?=$key['qty']?><?=$key['unit1_name']?></td>
          <td><?=$key['qty']*$key['unit2']?><?=$key['unit2_name']?></td>
          <td><?=$key['qty']*$key['unit_price']?></td>

        </tr>


 <?php }?>

<tr>
  <td colspan="4">Total Bar Expense Cost</td>
<td><?=$total_bar?></td>

</tr>


    </table>
  
  <?php }?>

  </div>
  
  <div class="col-lg-4">
    <?php
    $total_bbq=0;
if($bbq != null){

   

    ?> 
    <h3>barbeque counter expense</h3>
    <table class="table table-bordered " style="margin-top:10px;">
      <tr>
      <th style="background-color: #777777; ">Expense Name</th>
      <th>Unit Price</th>
      <th>Unit</th>
      <th>Converted Unit</th>
      <th>Total Cost</th>
    </tr>
<?php 
      foreach ($bbq as $key ) {
        # code...
        $total_bbq=$total_bbq+($key['qty']*$key['unit_price']);


        ?>
     <tr>
          <td><?=$key['outcome_name'];?></td>
          <td><?=$key['unit_price']?></td>
          <td><?=$key['qty']?><?=$key['unit1_name']?></td>
          <td><?=$key['qty']*$key['unit2']?><?=$key['unit2_name']?></td>
          <td><?=$key['qty']*$key['unit_price']?></td>

        </tr>

 <?php }?>

<tr>
  <td colspan="4">Total Barbeque Expense Cost</td>
<td><?=$total_bbq?></td>

</tr>

    </table>
  
  <?php }


$etotal=$total_kitchen+$total_bar+$total_bbq;
  ?>

 

  </div>
  

</div>
<div class="alert alert-info" role="alert">
  <a href="#" class="alert-link">Total Expense   is  <?=$etotal?>  </a>
</div>

</div>
   </script>