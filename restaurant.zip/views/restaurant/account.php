<?php
   use yii\bootstrap\ActiveForm;
   use yii\bootstrap\Html;
?>

<div class="restaurant-section">

<div class="body-content">




<?php $form = ActiveForm::begin(
  [
              'action' => '/restaurant/web/index.php?r=restaurant%2Faccounts',
              'options' => [
                  'class' => 'form-inline'
               ]
          ]
  ); ?>

  <select class="form-control form-inline" name="section">


          <?php

            for ($i=0; $i<sizeof($section);$i++) {
              // code...



        if($sec == $section[$i]['id']){
?>
          <option value="<?=$section[$i]['id']?>" style="color:red;" selected><?=$section[$i]['name']?></option>
<?php
}else{?>
  <option value="<?=$section[$i]['id']?>" style="color:red;"><?=$section[$i]['name']?></option>

          <?php
        }
      }
        ?>
       </select>




       <select class="form-control form-inline" name="check">
         <option value="0" style="color:red;" selected>Day</option>
         <option value="1" style="color:red;" >Month</option>
         <option value="2>" style="color:red;" >Year</option>
       </select>
       <input type="date" name="date">
    <button type="submit" class="btn btn-primary">Search</button>
    <h3>Sale Report For <?=$date?> is printed out at
  <?php 
                date_default_timezone_set("Asia/Yangon");  
               

               echo date("Y/m/d"); 
               ?>
                
               <?php
               echo date("h:i:sa")



              ?>

             

            </h3>
  <?php ActiveForm::end(); ?>



<div class="row">
  <div class="col-lg-6">


<?php
$total=0;
$qty=0;

   if ($data != null) {
     // code...

  ?>

      <table class="table table-bordered" style="margin-top:10px;">
        <tr>
          <th style="background-color:#777777;">Food Name</th>
          <th>Unit Price</th>
          <th>Qty</th>
          <th>Total</th>
        </tr>

        <?php
          foreach ($data as $d) {
            // code...
            $total+=$d['total'];
            $qty+=$d['qty'];
            
        ?>
          <tr>
              <td><?= $d['food_name']?></td>
              <td><?= $d['price']?></td>
              <td><?= $d['qty']?></td>
              <td><?= $d['total']?></td>
              
    

          </tr>
      <?php }?>

      <tr>
         <td style="color:red;" colspan="2">Total Income for other</td>
       
         <td><?=$qty?></td>
        <td><?=$total?></td>
      </tr>




      </table>

<?php } ?>
</div>
<div class="col-lg-6">


<?php
$total1=0;
$qty1=0;

   if ($drink != null) {
     // code...

  ?>

    <table class="table table-bordered" style="margin-top:10px;">
      <tr>
        <th style="background-color:#777777;">Drink Name</th>
        <th>Unit Price</th>
        <th>Qty</th>
        <th>Total</th>
      </tr>

      <?php
        foreach ($drink as $d) {
          // code...
          $total1+=$d['total'];
          $qty1+=$d['qty'];
          
      ?>
        <tr>
            <td><?= $d['food_name']?></td>
            <td><?= $d['price']?></td>
            <td><?= $d['qty']?></td>
            <td><?= $d['total']?></td>
            
  

        </tr>
    <?php }?>

    <tr>
       <td style="color:red;" colspan="2">Total Income for Drinks</td>
     
       <td><?=$qty1?></td>
      <td><?=$total1?></td>
    </tr>




    </table>

<?php }

$etotal =$total1+$total;
$tax =$etotal*(5/100);
$gtotal=$etotal+$tax;
 ?>
</div>
</div>

<div class="alert alert-info" role="alert">
  <a href="#" class="alert-link">Total Income   is  <?=$etotal?>  </a>
</div>

<div class="alert alert-info" role="alert">
  <a href="#" class="alert-link">Tax   is  <?=$tax?>  </a>
</div>
<div class="alert alert-info" role="alert">
  <a href="#" class="alert-link">Grand Total  is  <?=$gtotal?>  </a>
</div>