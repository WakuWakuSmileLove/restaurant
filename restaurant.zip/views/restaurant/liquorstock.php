<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model app\models\Liquorstock */
/* @var $form ActiveForm */
?>
<div class="Liquourstock">
  <div class="restaurant-food">

<div class="body-content">
  <table class="table table-striped table-bordered">
<thead class="thead-dark">
  <tr>
    <th scope="col">Number</th>
    <th scope="col">Food id</th>
    <th scope="col">Food Name</th>
    <th scope="col">Quantity</th>
    <th scope="col">Action</th>
  </tr>
</thead>
      
<?php   foreach ($liquor as $d) {    ?>
                      
        <tr class="service">

        <td class="tableitem"><p class="itemtext"><?= $d['id']?></p></td>
        <td class="tableitem"><p class="itemtext"><?= $d['food_id']?></p></td>
        <td class="tableitem"><p class="itemtext"><?= $d['food_name']?></p></td>
        <td class="tableitem"><p class="itemtext"><?= $d['total_qty']?></p></td>
        <td class="tableitem"><div><a class="btn" style="background-color:#563D7C;color:white;margin:0px;" id="tax" href="index.php?r=restaurant%2Fliqedit&id=<?=$d['id']?>">Add</a></div>

      </tr>




   <?php } ?>

</table>

</div>
</div>
</div>

