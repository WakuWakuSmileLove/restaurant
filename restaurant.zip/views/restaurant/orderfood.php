
<?php
  use yii\bootstrap\ActiveForm;
  use yii\bootstrap\Html;
use \yii\bootstrap\Widget;
use yii\helpers\Url;
 


?>
<?php $this->beginContent('@app/views/layouts/main_order.php'); ?>




<div style="background-color:gray;">
<?php foreach ($section_data as $ss ): ?>
  <?php if (isset($_GET['section']) && $_GET['section']== $ss['id']): ?>
    <a class="btn" style="background-color:#563D7C;color:white;margin:0px;" id="tax" href="<?php echo Url::base('http');  ?>/index.php?r=restaurant%2Ford&section&section=<?= $ss['id']?>"><?=$ss['name'];  ?></a>
  <?php elseif (!isset($_GET['section']) && $ss['id']==1):?>
    <a class="btn" style="background-color:#563D7C;color:white;margin:0px;" id="tax" href="<?php echo Url::base('http');  ?>/index.php?r=restaurant%2Ford&section&section=1"><?=$ss['name'];?></a>
<?php else: ?>
  <a class="btn" style="background-color:gray;color: white;" id="tax" href="<?php echo Url::base('http');  ?>/index.php?r=restaurant%2Ford&section&section=<?= $ss['id']?>"><?=$ss['name'];  ?></a>

  <?php endif; ?>
<?php endforeach; ?>

</div>



<table class="table table-striped table-bordered">
<thead class="thead-dark">
  <tr>
    <th scope="col">Item</th>
    <th scope="col">Description</th>
    <th scope="col">Qty</th>
    <th scope="col">Seat</th>
    <!-- <th scope="col">Sub Total</th> -->
    <th scope="col">Finish</th>
  </tr>
</thead>




                <?php

                $data_receipt = $data['data'];
                    foreach ($data_receipt as $d) {
                      // code...

                 ?>

<?php if ($d['finish']==1){?>
  <tr class="service" style="background:yellow;">
    <td class="tableitem"><h3><p class="itemtext"><?= $d['food_name']?></p></h3></td>
    <td class="tableitem"><h3 class="itemtext"><?= $d['desc']?></h3></td>
    <td class="tableitem"><p class="itemtext"><?= $d['qty']?></p></td>
    <td class="tableitem"><p class="itemtext"><?= $d['seat_num']?></p></td>
    <td class="tableitem" ><a href="/restaurant/web/index.php?r=restaurant%2Forderf&order_id=<?= $d['order_id']?>&order_history_id=<?= $d['order_history_id']?>&section=<?=$section?>" type="button" class="btn btn-primary" style="width:100%;">Finish</a></td>
    <td class="tableitem" ><a href="/restaurant/web/index.php?r=restaurant%2Forderd&order_id=<?= $d['order_id']?>&order_history_id=<?= $d['order_history_id']?>&section=<?=$section?>" type="button" class="btn btn-danger" style="width:100%;">Delete</a></td>

  </tr>
<?php }else{?>
  <tr class="service">
    <td class="tableitem"><h3><p class="itemtext"><?= $d['food_name']?></p></h3></td>
    <td class="tableitem"><h3 class="itemtext"><?= $d['desc']?></h3></td>
    <td class="tableitem"><p class="itemtext"><?= $d['qty']?></p></td>
    <td class="tableitem"><p class="itemtext"><?= $d['seat_num']?></p></td>
    <td class="tableitem" ><a href="/restaurant/web/index.php?r=restaurant%2Forderf&order_id=<?= $d['order_id']?>&order_history_id=<?= $d['order_history_id']?>&section=<?=$section?>" type="button" class="btn btn-primary" style="width:100%;">Finish</a></td>
    <td class="tableitem" ><a href="/restaurant/web/index.php?r=restaurant%2Forderd&order_id=<?= $d['order_id']?>&order_history_id=<?= $d['order_history_id']?>&section=<?=$section?>" type="button" class="btn btn-danger" style="width:100%;">Delete</a></td>

  </tr>
<?php } ?>
  <!-- <tr class="service" style="background:yellow;"> -->


<?php
}?>



</table>



<?php $this->endContent(); ?>
