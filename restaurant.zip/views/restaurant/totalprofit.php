<?php
   use yii\bootstrap\ActiveForm;
   use yii\bootstrap\Html;
?>

<div class="restaurant-section">

<div class="body-content">




<?php $form = ActiveForm::begin(
  [
              'action' => '/restaurant/web/index.php?r=restaurant%2Ftotalprofits',
              'options' => [
                  'class' => 'form-inline'
               ]
          ]
  ); ?>

  <select class="form-control form-inline" name="section">


          <?php

            for ($i=0; $i<sizeof($section);$i++) {
              // code...



        if($sec == $section[$i]['id']){
?>
          <option value="<?=$section[$i]['id']?>" style="color:red;" selected><?=$section[$i]['name']?></option>
<?php
}else{?>
  <option value="<?=$section[$i]['id']?>" style="color:red;"><?=$section[$i]['name']?></option>

          <?php
        }
      }
        ?>
       </select>




       <select class="form-control form-inline" name="check2">
         <option value="0" style="color:red;" selected>Month</option>
         <option value="1" style="color:red;" >Year</option>
        
       </select>
       <input type="date" name="date2">
    <button type="submit" class="btn btn-primary">Search</button>
    <h3>
  <?php 
                date_default_timezone_set("Asia/Yangon");  
               

               echo date("Y/m/d"); 
               ?>
                
               <?php
               echo date("h:i:sa")



              ?>

             

            </h3>
  <?php ActiveForm::end(); ?>

  <div class="row">
    <div class="col-lg-4">


      <?php 
      $total=0;

      if($income != null) {


      ?>

    <h4 style="margin-left: 10px">Income Summary</h4>

      <table class="table table-bordered" style="margin-top: 10px">
        <tr>
          <th> <center>Date</center></th>
          <th><center>Total Income</center></th>


        </tr>

        <?php 
        foreach($income as $d){
          $total+=$d['qty'];
        ?>
        <tr>
          <td><center><?=$d['date']?></center></td>
          <td><center><?=$d['qty']?></center></td>


        </tr>
        <?php }?>
        <tr>
          <td><center>Total</center></td>
          <td><center><?=$total?></center></td>

        </tr>
      </table>
    <?php }?>

    </div>

     <div class="col-lg-4">


      <?php 
      $total1=0;

      if($expense != null) {


      ?>

    <h4 style="margin-left: 10px">Expense Summary</h4>
      <table class="table table-bordered" style="margin-top: 10px">
        <tr>
          <th> <center>Date</center></th>
          <th><center>Total Expense</center></th>


        </tr>

        <?php 
        foreach($expense as $d1){
          $total1+=$d1['qty'];
        ?>
        <tr>
          <td><center><?=$d1['date']?></center></td>
          <td><center><?=$d1['qty']?></center></td>


        </tr>
        <?php }?>
         <tr>
          <td><center>Total</center></td>
          <td><center><?=$total1?></center></td>

        </tr>
      </table>
    <?php }?>

    </div>
    <div class="col-lg-4">


      <?php 
      $total=0;

      if($top != null) {


      ?>

    <h4 style="margin-left: 10px">Top 10 Best Selling Items</h4>

      <table class="table table-bordered" style="margin-top: 10px">
        <tr>
          <th> <center>Name</center></th>
          <th><center>Sold Quantity</center></th>


        </tr>

        <?php 
        foreach($top as $d){
         
        ?>
        <tr>
          <td><center><?=$d['food_name']?></center></td>
          <td><center><?=$d['qty']?></center></td>


        </tr>
        <?php }?>
       
      </table>
    <?php }?>

    </div>
    
  </div>
<div class="alert alert-info" role="alert">
  <a href="#" class="alert-link">Profit  is  <?=$total-$total1?>  </a>
</div>
