
  <?php
  use yii\bootstrap\ActiveForm;
  use yii\bootstrap\Html;
use \yii\bootstrap\Widget;
use yii\helpers\Url;
?>

<div class="restaurant-food">

<div class="body-content">

<div class ="row">
<div class="form-group col-md-6">
<?php $form = ActiveForm::begin([
        'method' => 'get',
        'action' => Url::to(['restaurant/foodupdate']),
]);
  
                 foreach ($food as $data) {



?>
<label>Food Id</label>
<input type="text" name="fid" class="form-control" value="<?=$data['id']?>">

 </br>
<label>Food Name</label>
<input type="text" name="fname" class="form-control" value="<?=$data['food_name']?>" />

 </br>
<label>Food Price</label>
    <input type="text" name="fprice" class="form-control" value="<?=$data['price']?>" />

 </br>
<label>Food Type</label>
    <input type="text" name="ftype" class="form-control" value="<?=$data['type']?>"/>

 </br></br>
     <input type="submit" class="btn btn-primary" value="Update">

   <?php ActiveForm::end();} ?>
</div>
</div>
</div>
</div>