<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model app\models\Liquorstock */
/* @var $form ActiveForm */
?>
<div class="restaurant-food">

<div class="body-content">

<div class ="row">
<div class="form-group col-md-6">
<?php $form = ActiveForm::begin([
        'method' => 'get',
        'action' => Url::to(['restaurant/liqupdate']),
]);
  
                 foreach ($liquorstock as $data) {



?>


<input type="hidden" name="fid" class="form-control" value="<?=$data['food_id']?>"  />

 </br>
<label>Food Name</label>
    <input type="text" name="fname" class="form-control" value="<?=$data['food_name']?>" disabled />

 </br>

 <label > Current Quantity : <?=$data['total_qty'] ?></label>
 <input type="hidden" name="cqty" value="<?=$data['total_qty'] ?>"/> 
</br>
<label>Add Quantity</label>
    <input type="text" name="fqty" class="form-control" required />

 </br></br>
     <input type="submit" class="btn btn-primary" value="Add">

   <?php ActiveForm::end();} ?>
</div>
</div>
</div>
</div>