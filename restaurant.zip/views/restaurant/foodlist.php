<?php
   use yii\bootstrap\ActiveForm;
   use yii\bootstrap\Html;
 use \yii\bootstrap\Widget;



?>


<div>
    <table>
      <tr>
        <th>Food Name</th>
        <th>Price</th>
      </tr>

      <?php
        foreach ($data as $d) {
          // code...

      ?>
        <tr>
            <td><?= $d['food_name']?></td>
            <td><?= $d['price']?></td>

        </tr>
    <?php }?>


    </table>


</div>
